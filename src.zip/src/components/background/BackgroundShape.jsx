import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

import "./backgroundShape.css"

gsap.registerPlugin(ScrollTrigger)

export default function BackgroundShape() {

  const blobRef = useRef()

  useEffect(() => {

    const ctx = gsap.context(() => {

      const blob = blobRef.current

      // entrada inicial
      gsap.fromTo(
        blob,
        {
          y: 400,
          scale: 0.3,
          rotation: -20,
          transformOrigin: "50% 50%"
        },
        {
          y: 0,
          scale: 1,
          rotation: 0,
          duration: 1.8,
          ease: "power3.out"
        }
      )

      // rotação contínua
      gsap.to(blob, {
        rotation: 360,
        duration: 40,
        repeat: -1,
        ease: "none",
        transformOrigin: "50% 50%"
      })

      // pulsação
      gsap.to(blob, {
        scale: 1.05,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut"
      })

      // movimento geral com scroll
      gsap.to(blob, {
        y: 600,
        scrollTrigger: {
          trigger: document.body,
          start: "top top",
          end: "bottom bottom",
          scrub: 1
        }
      })

      // hero
      gsap.to(blob, {
        y: -100,
        scale: 1.1,
        scrollTrigger: {
          trigger: "#hero",
          start: "top center",
          end: "bottom center",
          scrub: true
        }
      })

      // intro
      gsap.to(blob, {
        y: 100,
        scale: 1.2,
        scrollTrigger: {
          trigger: "#intro",
          start: "top center",
          end: "bottom center",
          scrub: true
        }
      })

      // projects
      gsap.to(blob, {
        y: 300,
        scale: 1.25,
        scrollTrigger: {
          trigger: "#projects",
          start: "top center",
          end: "bottom center",
          scrub: true
        }
      })

      // deformação orgânica
      gsap.to(blob, {
        attr: {
          d: "M300,100C420,80,520,200,480,340C420,520,180,520,120,360C80,200,200,80,300,100Z"
        },
        duration: 5,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut"
      })

    })

    return () => ctx.revert()

  }, [])

  return (
    <div className="background_shape">

      <svg viewBox="0 0 600 600">

        <path
          ref={blobRef}
          fill="#B87333"
          d="M300,120C380,80,470,160,470,280C470,420,380,500,260,480C150,460,90,380,120,260C150,150,220,110,300,120Z"
        />

      </svg>

    </div>
  )
}